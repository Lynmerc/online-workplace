<?php

namespace App\Http\Controllers;

use App\User;
use App\Admin;
use App\Users;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Http\Request;

class RegisterController extends Controller
{
    public function __construct(){
        $this->middleware('guest');
        $this->middleware('guest:admin');
        $this->middleware('guest:users');
    }

    public function admin(){
        return view('auth.register', ['url' => 'admin']);
    }

    public function user(){
        return view('auth.register', ['url' => 'users']);
    }

    public function createAdmin(Request $request){
        $this->validator($request->all())->validate();
        $admin = Admin::create([
            'firstName' => $request['firstName'],
            'lastName' => $request['lastName'],
            'email'  => $request['email'],
            'password' => Hash::make($request['password']);
        ]);

        return redirect()->intended('login/admin');
    }

    public function createUsers(Request $request){
        $this->validator($request->all())->validate();
        $users = Users::create([
            'firstName' => $request['firstName'],
            'lastName' => $request['lastName'],
            'email'  => $request['email'],
            'password' => Hash::make($request['password']);
        ]);

        return redirect()->intended('login/users');
    }
}
