<!doctype html>
<html lang="en">
  <head>
  	<title>Job Details</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href=" <?php echo e(asset('css/style.css')); ?>">
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<div class="custom-menu">
					<button type="button" id="sidebarCollapse" class="btn btn-primary">
	          <i class="fa fa-bars"></i>
	          <span class="sr-only">Toggle Menu</span>
	        </button>
        </div>
				<div class="p-4">
		  		<h1><a href="index.html" class="logo">Freelanc <span>Freelancer Agency</span></a></h1>
	        <ul class="list-unstyled components mb-5">
	          <li class="active">
	            <a href="./usr/jobs"><span class="fa fa-suitcase mr-3"></span>Work List</a>
	          </li>
	          <li>
	              <a href="./usr/profile"><span class="fa fa-user mr-3"></span>Profile</a>
	          </li>
	          <li>
              <a href="./usr/progress"><span class="fa fa-briefcase mr-3"></span>In Progress</a>
	          </li>
	          <li>
              <a href="./usr/applications"><span class="fa fa-sticky-note mr-3"></span>Applications</a>
	          </li>
	        </ul>

	        <div class="mb-5">
						<h3 class="h6 mb-3">Subscribe for info</h3>
						<form action="#" class="subscribe-form">
	            <div class="form-group d-flex">
	            	<div class="icon"><span class="icon-paper-plane"></span></div>
	              <input type="text" class="form-control" placeholder="Enter Email Address">
	            </div>
	          </form>
					</div>

	        <div class="footer">
	        	<p>
						  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | <a href="https://lynmerc-enterprise.com" target="_blank" style="color: white;">Lynmercan</a>
						  </p>
	        </div>

	      </div>
    	</nav>
    	
        <!-- Page Content  -->
	      <div id="content" class="p-4 p-md-5 pt-5">
	      	<h3>Details</h3>
	      	<?php echo csrf_field(); ?>
	      	<div class="row">
	      		<div class="col-md-1">	      			
	      		</div>
	      		<div class="col-md-10">
	      			<?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	      						      		
				      		<div class="col-md-10">
				      			<div class="row">
				      				<div class="col-md-2">
				      					Title:
				      				</div>
				      				<div class="col-md-10">
				      					<?php echo e($job->title); ?>

				      				</div>
				      			</div><br />
				      			<div class="row">
				      				<div class="col-md-2">
				      					Description:
				      				</div>
				      				<div class="col-md-10">
				      					<?php echo e($job->fullDesc); ?>

				      				</div>
				      			</div>	<br />			      		
					      		<div class="col-md-10">
					      			<div class="row">
					      				<div class="col-md-2">
					      					Deadline:
					      				</div>
					      				<div class="col-md-10">
					      					<?php echo e($job->deadline); ?>

					      				</div>
					      			</div>
					      		</div><br />
					      		<div class="col-md-10">
					      			<div class="row">
					      				<div class="col-md-2">
					      					Category:
					      				</div>
					      				<div class="col-md-10">
					      					<?php echo e($job->category); ?>

					      				</div>
					      			</div>
					      		</div><br />
					      		<div class="col-md-10">
					      			<div class="row">
					      				<div class="col-md-2">
					      					Mentor:
					      				</div>
					      				<div class="col-md-10">
					      					<?php echo e($job->mentor); ?>

					      					<input type="hidden" name="mentor" value="<?php echo e($job->mentor); ?>">
					      					<input type="hidden" name="employerId" value="<?php echo e($job->employerId); ?>">
					      					<input type="hidden" name="jobId" value="<?php echo e($job->jobId); ?>">
					      				</div>
					      			</div>
					      		</div><br />
					      		<div class="col-md-10">
					      			<div class="row">
					      				<div class="col-md-2">
					      					Amount:
					      				</div>
					      				<div class="col-md-10">
					      					<?php echo e($job->cost); ?>

					      				</div>
					      			</div>
					      		</div><br />
					      		<div class="col-md-10">
					      			<div class="row">
					      				<div class="col-md-2">
					      					
					      				</div>
					      				<div class="col-md-10">
					      					<button class="btn-primary" href="./mtr/list">Back</button>
					      				</div>
					      			</div>
				      			</div><br />	
				      		</div>		      		
	      			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	      		</div>
	      		<div class="col-md-1">
	      			
	      		</div>
	      	</div>	        
	      </div>

			
		</div>

    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
  </body>
</html><?php /**PATH C:\wamp\www\muli\resources\views/mentors/jobdetails.blade.php ENDPATH**/ ?>