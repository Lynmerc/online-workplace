(function($) {

	"use strict";

	var fullHeight = function() {

		$('.js-fullheight').css('height', $(window).height());
		$(window).resize(function(){
			$('.js-fullheight').css('height', $(window).height());
		});

	};
	fullHeight();

	$('#sidebarCollapse').on('click', function () {
      $('#sidebar').toggleClass('active');
  });

})(jQuery);

var checker = document.getElementById('checkme');
		 var sendbtn = document.getElementById('upload');
		 // when unchecked or checked, run the function
		 checker.onchange = function(){
		if(this.checked){
		    sendbtn.disabled = false;
		} else {
		    sendbtn.disabled = true;
		}

		}
