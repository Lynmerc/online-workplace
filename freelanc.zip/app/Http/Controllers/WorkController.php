<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;
use App\Http\Requests;
use Illuminate\Foundation\Validation\ValidatesRequests;


class WorkController extends Controller
{
      //$myUserId ="";
      public $rules = array(
         'userId'=>'required',
         'mentor'=>'required',

      );
   	public function user_apply(){

   	}

   	public function user_submit(){

   	}

   	public function checkIfUserHasWork($userId){
   		$bd = DB::table('jobs');         
         $check = $bd->get(array('jobId'))->where('userId','=',$userId)->where('inProgress','=','1');
         if(count($check)>0){
            $this->showWorkInProgress();          
         }
   	}
      public function mentorJobView(){
         session_start();
         if(!isset($_SESSION['mentorId'])){
            return redirect()->intended('./mtr/login');
         }
         
         $mentorId = $_SESSION['mentorId'];

         $jobs = DB::select('SELECT * FROM jobs WHERE inProgress="0"');
         return view('mentors.jobs',[
            'jobs'=>$jobs,
            'mentorId'=>$mentorId,
            
         ]);
         
         $jobs = DB::select('SELECT * FROM jobs WHERE inProgress="0"');
         return view('mentors.jobs',['jobs'=>$jobs]);

      }

      

   	public function fetchNewJobs(){
         session_start();
         if(!isset($_SESSION['userId'])){
            return redirect()->intended('./usr/login');
         }
         //$userId = $_SESSION['userId'];
         $i = 1;
         $modalId = 'exampleModalCenter'.$i;
         $modela = '#exampleModalCenter'.$i;
         $userId = $_SESSION['userId'];

         $this->checkIfUserHasWork($userId);
         $this->checkIfUserHasApplied($userId);

         $jobs = DB::select('SELECT * FROM jobs WHERE inProgress="0"');
         return view('users.jobs',[
            'jobs'=>$jobs,
            'userId'=>$userId,
            'i'=>$i, 
            'modalId'=>$modalId, 
            'modela'=>$modela
         ]);
         
   		$jobs = DB::select('SELECT * FROM jobs WHERE inProgress="0"');
   		return view('users.jobs',['jobs'=>$jobs,'i'=>$i, 'modalId'=>$modalId, 'modela'=>$modela]);

   	}

      public function showWorkInProgress(){
         session_start();
         if(!isset($_SESSION['userId'])){
            return redirect()->intended('./usr/login');
         }
         $userId = $_SESSION['userId'];
         $jobs = DB::select('SELECT * FROM jobs WHERE inProgress="1" and userId="'.$userId.'"'); //match user ID
         return view('users.progress', ['jobs'=>$jobs]);
      }

      public function checkIfUserHasApplied($userId){
         $bd = DB::table('applications');         
         $check = $bd->get(array('appId'))->where('userId','=',$userId)->where('status','=','2');
         if(count($check)>0){
            $this->showApplications();          
         }
      }

      public function showApplications(){
         session_start();
         if(!isset($_SESSION['userId'])){
            return redirect()->intended('./usr/login');
         }

         $userId = $_SESSION['userId'];
         $db = DB::table('jobs');
         $bd = DB::table('applications');         
         $check = $bd->get()->where('userId','=',$userId)->where('status','=','2');
         if($check){
            
            $chec = json_decode($check, true)[0];
            $jobId = $chec['jobId'];
           $jobs = $db->get()->where('jobId','=',$chec['jobId']);
            if($jobs){
               $job = json_decode($jobs,true)[0];
               $status = "Pending Review";
               //echo $job['title'];
               return view('users.applications',['job'=>$job,'status'=>$status]);
            }
            
         }
         /*
            $userId = $_SESSION['userId'];
            $db = DB::table('applications');
            $bd = DB::table('jobs');

            $link = $db->where('userId'=>$userId);
            if($link){
               $result = json_decode($link,true)[0];
               $jobId = $result['jobId'];
               $jobS = $bd->where('jobId'=>$jobId);
               if($jobS){
                  $jobs = json_decode($jobS,true)[0]
               }
            }

            $pending = DB::select('SELECT * FROM applications WHERE status="2" AND userId="'.$userId.'"'); 
            $declined = DB::select('SELECT * FROM applications WHERE status="0" AND userId="'.$userId.'"');
            $approved ;
            return view('users.applications',['jobs'=>$applications, 'decl'=>$declined]);*/
         
      }

      public function showDetails(Request $request){
         session_start();         
         if(!isset($_SESSION['userId'])){
            return redirect()->intended('./usr/login');
         }
         $userId = $request->userId;

         $this->checkIfUserHasApplied($userId);

         $jobId =$request->jobId;
         //echo $jobId; --useless herr

         $jobs = DB::select('SELECT * FROM jobs WHERE jobId="'.$jobId.'"');
         return view('users.apply',['jobs'=>$jobs,'jobId'=>$jobId,'userId'=>$userId]);
      }

      public function apply(Request $request){
         session_start();
         if(!isset($_SESSION['userId'])){
            return redirect()->intended('./usr/login');
         }

         


         $db = DB::table('applications');
         $userId = $_SESSION['userId'];
         $this->checkIfUserHasApplied($userId);
         $jobId = $request->jobId;
         $employerId = $request->employerId;
         $mentor = $request->mentor;
         $status = "2";
         $data = array([
            'employerId' =>$employerId,
            'jobId' =>$jobId,
            'mentor' =>$mentor,
            'status' =>$status,
            'userId'=>$userId,
         ]) ;
         if(!isset($_SESSION['userId'])){
            return redirect()->intended('./usr/login');
         }

         if(!isset($request)){
            http_response_code(400);
         }

         //activate if you want to validate data
         
         $validator = \Validator::make($data, $this->rules);

         if($validator->fails()){
            http_response_code(400);
         }

         $apply = $db->insert($data);
         //$apply = DB::insert('INSERT INTO applications (userId,jobId,employerId,mentor,status) values (?,?,?,?,?)'),[$userId,$jobId,$employerId,$mentor,1]; --uncomment to use raw sql
         if($apply){
            http_response_code(200);
            $__alert = "<script type='text/javascript'>window.onload = function(){alert('Application successful');}</script>";
            return redirect()->intended('./usr/applications');
         }else{
            http_response_code(500);
         }

         //return view('users.applications');

      }
}
