<p align="center"><img src="https://res.cloudinary.com/dtfbvvkyp/image/upload/v1566331377/laravel-logolockup-cmyk-red.svg" width="400"></p>



## About Freelanc
Freelanc is a simple tool to help anyone manage their employees, admins can post jobs here and the users can apply to work once applied, the admins select who to assign the job to. When done, the users upload their work back and the admin can download it.


## Contributing
This project was developed using Laravel framework
You can also contribute to Laravel, The contribution guide can be found in the [Laravel documentation](https://laravel.com/docs/contributions).

## Security Vulnerabilities

If you discover a bug within Freelanc, please send an e-mail to Collins Amanya via [collins@lynmerc-enterpise.com](mailto:collins@lynmerc-enterpise.com). All security vulnerabilities will be promptly addressed.

If you discover a security vulnerability within Laravel, please send an e-mail to Taylor Otwell via [taylor@laravel.com](mailto:taylor@laravel.com). All security vulnerabilities will be promptly addressed.

## License

The Laravel framework is open-source software licensed under the [MIT license](https://opensource.org/licenses/MIT).
