<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Hash;
use DB;


class LoginController extends Controller
{
        public function facade(Request $request){
        /*$this->validate($request, [
            'email' => 'required|email',
            'password'=>'required|min8'
        ]);*/ //uncomment to use lv validator instead of the one below
        $data = array([
            'email'=>$request->email, 
            'password'=>$request->password
        ]);

        $validator = \Validator::make($data,[
            'username' => 'required',
            'password' => 'required'
        ]);

        if($validator->fails()){
            http_response_code(406);
        }

        $db = DB::table('user');
        $password = Hash::make($request->password);
        
        $__loger = DB::table('user')->where('email','=',$request->email);
        $email = $request->email;
        //$__loger = DB::select('SELECT * FROM user WHERE email="'.$email.'"'); 
        //echo $__loger;
        //$__loger = $__loger->get(); --uncomment when using ::table()
        $__loger = $db->get(array('userId','email','password'))->where('email',$request['email']);

        if(count($__loger)==1){
            $results = json_decode($__loger, true)[0];
            $pass = $request['password'];
            echo $results['email'];
            if(\Hash::check($pass, $results['password'])){
                session_start();
                $_SESSION['userId'] = $results['userId'];
                http_response_code(200);
                return redirect()->intended('./usr/jobs');
            }else{
                http_response_code(403);
            }

        }else{
            http_response_code(403);
        }
    }
    public function users(){
        return view('auth.login',['url' => 'users']);
    }

    public function usersLogin(Request $request){
        $this->validate($request, [
            'email' => 'required|email',
            'password' => 'required|min:8'
        ]);

        if (Auth::guard('users')->attempt(['email'=>$request->email, 'password'=>$request->password], $request->get('remember'))){
            return redirect()->intended('/users');
        }

        return back()->withInput($request->only('email','remember'));
    }

    public function showProfile(){
        session_start();
        if(!isset($_SESSION['userId'])){
            return redirect()->intended('./usr/login');
        }

        $userId = $_SESSION['userId'];

        $db = DB::table('user');

        $fetch = $db->get()->where('userId',$userId);

        if($fetch){
            $profile = json_decode($fetch, true)[0];
            $firstName = $profile['firstName'];
            $lastName = $profile['lastName'];
            $category = $profile['category'];
            $email = $profile['email'];
            //$mentor = $profile['mentor'];

            return view('users.profile',[
                'firstName'=>$firstName, 
                'lastName'=>$lastName,
                'category'=>$category,
                'email'=>$email,
                'userId'=>$_SESSION['userId'],
                'mentor'=>'',
            ]);
        }
    }

    public function mentorProfile(){
        session_start();
        if(!isset($_SESSION['mentorId'])){
            return redirect()->intended('./mtr/login');
        }

        $mentorId = $_SESSION['mentorId'];

        $db = DB::table('mentors');

        $fetch = $db->get()->where('mentorId',$mentorId);

        if($fetch){
            $profile = json_decode($fetch, true)[0];
            $firstName = $profile['firstName'];
            $lastName = $profile['lastName'];
            $email = $profile['email'];
            //$mentor = $profile['mentor'];

            return view('mentors.profile',[
                'firstName'=>$firstName, 
                'lastName'=>$lastName,
                'email'=>$email,
                'userId'=>$_SESSION['mentorId'],
            ]);
        }
    }

    public function mtrLogin(Request $request){
        $data = array([
            'email'=>$request->email, 
            'password'=>$request->password
        ]);

        $validator = \Validator::make($data,[
            'email' => 'required',
            'password' => 'required'
        ]);

        if($validator->fails()){
            http_response_code(403);
        }

        $db = DB::table('mentors');
        $password = Hash::make($request->password);
        
        $__loger = DB::table('mentors')->where('email','=',$request->email);
        $email = $request->email;
        //$__loger = DB::select('SELECT * FROM mentors WHERE email="'.$email.'"'); 
        //echo $__loger;
        //$__loger = $__loger->get(); --uncomment when using ::table()
        $__loger = $db->get(array('mentorId','email','password'))->where('email',$request['email']);

        if(count($__loger)==1){
            $results = json_decode($__loger, true)[0];
            $pass = $request['password'];
            echo $results['email'];
            if(\Hash::check($pass, $results['password'])){
                session_start();
                $_SESSION['mentorId'] = $results['mentorId'];
                http_response_code(200);
                return redirect()->intended('./mtr/list');
            }else{
                http_response_code(403);
                return redirect()->intended('./mtr/login');
            }

        }else{
            http_response_code(403);
            return redirect()->intended('./mtr/login');
        }

    }

    public function bgAdd(Request $request){
        session_start();
        if(!isset($_SESSION['mentorId'])){
            return redirect()->intended('./mtr/login');
        }

        $db = DB::table('user');
        $status = "1";
        $password = Hash::make($request->password);

        $data = array([
            'firstName'=>$request->firstName,
            'lastName'=>$request->lastName,
            'email'=>$request->email,
            'category'=>$request->category,
            'password'=>$password,
            'active'=>$status,
        ]);

        $checkemail= $db->get(array('email','password'))->where('email',$request['email']);

        if(count($checkemail)>0){
            echo "user already exists. Use another email";
            sleep(10);
            return redirect()->intended('./mtr/adduser');
        }


        $add = $db->insert($data);

        if($add){
            echo "New User Added";
            sleep(5);
            return redirect()->intended('./mtr/adduser');
        }else{
            echo "Unknown Error.";
        }
    }

    public function logout(){
        session_destroy();
        return redirect()->intended('./login');
    }
}
