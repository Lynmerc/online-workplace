<!doctype html>
<html lang="en">
  <head>
  	<title>Add Job</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href=" <?php echo e(asset('css/style.css')); ?>">
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<div class="custom-menu">
					<button type="button" id="sidebarCollapse" class="btn btn-primary">
	          <i class="fa fa-bars"></i>
	          <span class="sr-only">Toggle Menu</span>
	        </button>
        </div>
				<div class="p-4">
		  		<h1><a href="index.html" class="logo">Freelanc <span>Freelancer Agency</span></a></h1>
	        <ul class="list-unstyled components mb-5">
	          <li>
	            <a href="./jobs">Work List</a>
	          </li>
	          <li>
	              <a href="./profile">Profile</a>
	          </li>
	          <li >
	              <a href="./adduser">Add User</a>
	          </li>
	          <li class="active">
	              <a href="./newjob">Add Job</a>
	          </li>
	          <li>
              <a href="./progress"></span>In Progress</a>
	          </li>
	          <li>
              <a href="./applications">Applications</a>
	          </li>
	          <li>
	              <a href="./submits">Submissions</a>
	          </li>
	        </ul>

	        <div class="mb-5">
						<h3 class="h6 mb-3">Subscribe for info</h3>
						<form action="#" class="subscribe-form">
	            <div class="form-group d-flex">
	            	<div class="icon"><span class="icon-paper-plane"></span></div>
	              <input type="text" class="form-control" placeholder="Enter Email Address">
	            </div>
	          </form>
					</div>

	        <div class="footer">
	        	<p>
						  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | <a href="https://lynmerc-enterprise.com" target="_blank" style="color: white;">Lynmercan</a>
						  </p>
	        </div>

	      </div>
    	</nav>
    	
    	
        <!-- Page Content  -->
	      <div id="content" class="p-4 p-md-5 pt-5">
	      	<h3 class="mb-4">Add a new job</h3> <hr />
	      	<div class="row">	      		
	      		<div class="col-md-1"></div>
	      		<div class="col-md-10">
	      			<form method="POST" action="./mtr/postjob">
	      				<div class="row">
	      					<div class="col-md-3">
	      						<strong>Title:</strong>
	      					</div>
	      					<div class="col-md-9">
	      						<input style="width: 100%" type="text" name="title" required>
	      					</div>
	      				</div><br />

	      				<div class="row">
	      					<div class="col-md-3">
	      						<strong>Category:</strong>
	      					</div>
	      					<div class="col-md-9">
	      						<input style="width: 100%" type="text" name="category" required>
	      					</div>
	      				</div><br />

	      				<div class="row">
	      					<div class="col-md-3">
	      						<strong>Short Description:</strong>
	      					</div>
	      					<div class="col-md-9">
	      						<input style="width: 100%" type="text" name="shortDesc" required>
	      					</div>
	      				</div><br />

	      				<div class="row">
	      					<div class="col-md-3">
	      						<strong>Full Description:</strong>
	      					</div>
	      					<div class="col-md-9">
	      						<textarea style="width: 100%;" type="text" name="category" required></textarea>
	      					</div>
	      				</div> <br />

	      				<div class="row">
	      					<div class="col-md-3">
	      						<strong>Deadline:</strong>
	      					</div>
	      					<div class="col-md-9">
	      						<input style="width: 100%" type="date" name="deadline" required>
	      					</div>
	      				</div> <br />

	      				<div class="row">
	      					<div class="col-md-3">
	      						<strong>Amount:</strong>
	      					</div>
	      					<div class="col-md-9">
	      						<input style="width: 100%" type="text" name="cost" required>
	      					</div>
	      				</div> <br /> <br />

	      				<div class="row">
	      					<div class="col-md-4">
	      						<input type="submit" class="btn btn-primary" value="Add Job">
	      					</div>
	      					<div class="col-md-4">
	      						<button class="btn btn-success" href="./mtr/list">Go Home</button>
	      					</div>
	      					<div class="col-md-4">
	      						<button class="btn btn-danger">Cancel</button>
	      					</div>
	      				</div>

	      			</form>
	      		</div>
	      		<div class="col-md-1"></div>
	      	</div>
	        
	      </div>


		</div>

    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
  </body>
</html><?php /**PATH C:\wamp\www\muli\resources\views/mentors/addjob.blade.php ENDPATH**/ ?>