<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;

class UploadController extends Controller
{
    public function upload(Request $request){
    	$file = $request->file('image');
    	$fileName = $file->getClientOriginalName();
    	$ext = $file->getClientOriginalExtension();
    	$path = $file->getRealPath();
    	$size = $file->getSize();
    	$type = $file->getMimeType();
    	$destination = 'uploads';
    	//$db = DB::table('jobs');
    	$bd = DB::table('submissions');
    	$data = array([
    		'fileName'=>$fileName, 
    		'fileSize'=>$size], 
    		'destination'=>$destination,
    		'jobId'=>$jobId,
    		'userId'=>$userId
    	)

    	$upload = $bd->insert()


    	$file->move($destination, $file->getClientOriginalName());
    }
}
