<!doctype html>
<html lang="en">
  <head>
  	<title>Work in Progress</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href=" {{asset('css/style.css')}}">
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<div class="custom-menu">
					<button type="button" id="sidebarCollapse" class="btn btn-primary">
	          <i class="fa fa-bars"></i>
	          <span class="sr-only">Toggle Menu</span>
	        </button>
        </div>
				<div class="p-4">
		  		<h1><a href="index.html" class="logo">Freelanc <span>Freelancer Agency</span></a></h1>
	        <ul class="list-unstyled components mb-5">
	          <li>
	            <a href="./jobs">Work List</a>
	          </li>
	          <li>
	              <a href="./profile">Profile</a>
	          </li>
	          <li >
	              <a href="./adduser">Add User</a>
	          </li>
	          <li>
	              <a href="./newjob">Add Job</a>
	          </li>
	          <li class="active">
              <a href="./progress"></span>In Progress</a>
	          </li>
	          <li>
              <a href="./applications">Applications</a>
	          </li>
	          <li>
	              <a href="./submits">Submissions</a>
	          </li>
	        </ul>

	        <div class="mb-5">
						<h3 class="h6 mb-3">Subscribe for info</h3>
						<form action="#" class="subscribe-form">
	            <div class="form-group d-flex">
	            	<div class="icon"><span class="icon-paper-plane"></span></div>
	              <input type="text" class="form-control" placeholder="Enter Email Address">
	            </div>
	          </form>
					</div>

	        <div class="footer">
	        	<p>
						  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved  <a href="https://lynmerc-enterprise.com" target="_blank" style="color: white;">Lynmercan</a>
						  </p>
	        </div>

	      </div>
    	</nav>
    	
    	
        <!-- Page Content  -->
	      <div id="content" class="p-4 p-md-5 pt-5">
	      	<h3 class="mb-4">Work in Progress</h3> <hr />
	      	<div class="row">	      		
	      		<div class="col-md-1"></div>
	      		<div class="col-md-10">
	      			@foreach($jobs as $job)
			        <div class="card mb-3" id="card" style="max-width: 640px;">
					  <div class="row no-gutters">
					    <div class="col-md-4">
					      <img src="./images/user.png" class="card-img" alt="...">
					    </div>
					    <div class="col-md-8">
					      <div class="card-body">
					        <h5 class="card-title" style="color: blue;">{{$job->title}}</h5>
					        <p class="card-text">{{$job->shortDesc}}</p>
					        <p class="small"><strong>Category:</strong> {{$job->category}} <strong>Amount:</strong> {{$job->cost}} <strong>Deadline:</strong>{{$job->deadline}} </p>
					      </div>
					      <div class="card-footer"><button class="btn-primary" data-toggle="modal" data-target="#exampleModalCenter">View & Submit</button></div>
					    </div>
					  </div>
					</div>

					<!-- Modal -->
					<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
					  <div class="modal-dialog modal-dialog-centered" role="document">
					    <div class="modal-content">
					      <div class="modal-header">
					        <h5 class="modal-title" id="exampleModalLongTitle">Submit your work</h5>
					        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
					          <span aria-hidden="true">&times;</span>
					        </button>
					      </div>
					      <div class="modal-body">
					        <h3 class="job-title">{{$job->title}}</h3>
					        <div class="row">
					        	<div class="col-md-12">
					        		<div class="alert alert-warning"><p><strong>NOTE:</strong> Compress all your files into one zip before uploading.</p></div>
					        	</div>
					        	
					        </div>
					        <div class="row">
					        	<div class="col-md-2">Description:</div>
					        	<div class="col-md-10">
					        		{{$job->fullDesc}}
					        	</div>
					        </div>
					        <div class="row">
					        	<div class="col-md-2">Deadline:</div>
					        	<div class="col-md-10">{{$job->deadline}}</div>
					        </div>
					        <div class="row">
					        	<div class="col-md-2">Payment:</div>
					        	<div class="col-md-10">{{$job->cost}}</div>
					        </div>
					        <div class="row">
					        	<div class="col-md-2">Mentor:</div>
					        	<div class="col-md-10">{{$job->mentor}}</div>
					        </div>
					        
					        <div class="row">
					        	<div class="col-md-2">Submit:</div>			        	
					        	<div class="col-md-10">
					        		<p><label for="uploads">Select a file</label></p>
					        		{{Form::open(array('url'=>'./uploads','files'=>'true'))}}			        		
					        	</div>
					        </div>
					        <div class="row">
					        	<div class="col-md-2"></div>
					        	<div class="col-md-10">
					        		<input type="hidden" name="jobId" value="{{$job->userId}}">   		
					        		<input type="checkbox" id="checkme" name="">
					        		<label for="checkme">Confirm submission? You must upload your zip file in the next page after clicking. This can't be undone!</label>
					        	</div>
					        </div>
					      </div>
					      <div class="modal-footer">
					        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
					        <button type="submitt" class="btn btn-primary" id="upload" disabled="disabled">Upload</button>
					      </div>
					  
					    </div>
					  </div>
					</div>

			@endforeach
	      		</div>
	      		<div class="col-md-1"></div>
	      	</div>
	        
	      </div>


		</div>

    <script src="{{asset('js/jquery.min.js')}}"></script>
    <script src="{{asset('js/popper.js')}}"></script>
    <script src="{{asset('js/bootstrap.min.js')}}"></script>
    <script src="{{asset('js/main.js')}}"></script>
  </body>
</html>