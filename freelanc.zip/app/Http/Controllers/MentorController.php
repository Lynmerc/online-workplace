<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;
use App\Http\Requests;
use Illuminate\Foundation\Validation\ValidatesRequests;


class MentorController extends Controller
{
      //$myUserId ="";
      public $rules = array(
         'mentorId'=>'required',
         'fullDesc'=>'required',
         'shortDesc'=>'required',
         'title'=>'requires',
         'cost'=>'required',
         'deadline'=>'required',
      );
   	public function user_apply(){

   	}

   	public function user_submit(){

   	}

   	public function checkIfUserHasWork($userId){
   		$bd = DB::table('jobs');         
         $check = $bd->get(array('jobId'))->where('userId','=',$userId)->where('inProgress','=','1');
         if(count($check)>0){
            $this->showWorkInProgress();          
         }
   	}
      public function mentorJobView(){
         session_start();
         if(!isset($_SESSION['mentorId'])){
            return redirect()->intended('./mtr/login');
         }
         
         $mentorId = $_SESSION['mentorId'];

         $jobs = DB::select('SELECT * FROM jobs WHERE inProgress="0"');
         return view('mentors.jobs',[
            'jobs'=>$jobs,
            'mentorId'=>$mentorId,
            
         ]);
         
         $jobs = DB::select('SELECT * FROM jobs WHERE inProgress="0"');
         return view('mentors.jobs',['jobs'=>$jobs]);

      }

    
      public function showWorkInProgress(){
         session_start();
         if(!isset($_SESSION['mentorId'])){
            return redirect()->intended('./mtr/login');
         }
         $mentorId = $_SESSION['mentorId'];
         $jobs = DB::select('SELECT * FROM jobs WHERE inProgress="1"'); //match user ID
         return view('mentors.progress', ['jobs'=>$jobs]);
      }

      public function checkIfUserHasApplied($userId){
         $bd = DB::table('applications');         
         $check = $bd->get(array('appId'))->where('userId','=',$userId)->where('status','=','2');
         if(count($check)>0){
            $this->showApplications();          
         }
      }

      public function showApplications(){
         session_start();
         if(!isset($_SESSION['mentorId'])){
            return redirect()->intended('./mtr/login');
         }

         $mentorId = $_SESSION['mentorId'];
         $db = DB::table('jobs');
         $bd = DB::table('applications');         
         $du = DB::table('user');

         //$job= $db->select('jobs.jobId','jobs.category','jobs.deadline','jobs.shortDesc','jobs.title','jobs.cost','applications.status','user.userId','user.firstName','user.lastName','applications.appId')->join('applications','applications.jobId','=','jobs.jobId')->join('user','user.userId','=','applications.userId')->where('applications.status','=','2')->get();

         //$job = $bd->select('jobs.jobId','jobs.category','jobs.deadline','jobs.shortDesc','jobs.title','jobs.cost','applications.status','user.userId','user.firstName','user.lastName','applications.appId')->join('jobs','jobs.jobId','=','applications.jobId')->join('user','user.userId','=','applications.userId')->where('applications.status','=','2')->get();
         $job = DB::select('SELECT jobs.jobId,jobs.category,jobs.deadline,jobs.shortDesc,jobs.title,jobs.cost,applications.status,user.userId,user.firstName,user.lastName,applications.appId FROM (jobs INNER JOIN applications ON applications.jobId = jobs.jobId) INNER JOIN user ON applications.userId = user.userId');

         //SELECT Orders.OrderID, Customers.CustomerName, Shippers.ShipperName FROM ((Orders INNER JOIN Customers ON Orders.CustomerID = Customers.CustomerID) INNER JOIN Shippers ON Orders.ShipperID = Shippers.ShipperID);
         if($job){
            //echo $job;d-
            //$jobs = json_decode($job, true)[0];
            //echo $job;
            return view('mentors.applications',['jobs'=>$job]);
         }else{
            echo "Technical Error: Contact Admin";
         }
         
      }

      public function respondToApplication(Request $request){
         if(!isset($_SESSION['mentorId'])){
            return redirect()->intended('./mtr/login');
         }
         $db = DB::table('jobs');
         $bd = DB::table('applications');

         $jobId = $request->jobId;
         $appId = $request->appId;
         $userId = $request->userId;
         $status = $request->status;

         $data = array([
            'inProgress'=>'1',
            'userId'=>$userId,
         ]);
         $data2 = array([
            'status'=>$status,
         ]);

         $job_update = $db->insert($data)->where('jobId','=',$jobId);

         

         if ($job_update) {
            $status_update = $bd->insert($data2)->where('appId','=',$appId);
            if($status_update){
               http_response_code(302);
               echo "Success..Redirecting ...";
               sleep(4);
               return redirect()->intended('./mtr/applications');
            }
         }else{
            echo "Technical Error: Contact Admin";
            sleep(4);
            session_destroy();
            http_response_code(412);
         }

      }

      public function postJob(Request $request){
         if(!isset($_SESSION['mentorId'])){
            return redirect()->intended('./mtr/login');
         }
         $data = array([
            'title'=>$request->title,
            'category'=>$request->category,
            'shortDesc'=>$request->shortDesc,
            'fullDesc'=>$request->fullDesc,
            'cost'=>$request->cost,
            'deadline'=>$request->deadline,
         ]);

         $db = DB::table('jobs');
         $validator = \Validator::make($data, $this->rules);

         if($validator->fails()){
            http_response_code(500);
            return redirect()->intended('./mtr/list');
         }

         $addJob = $db->insert($data);

         if($addJob){
            echo "New job added, redirecting...";
            sleep(4);
            return redirect()->intended('./mtr/newjob');
         }else{
            echo "Technical Error: Could not add job contact admin. Redirecting ....";
            sleep(4);
            return redirect()->intended('./mtr/list');
         }

      }

      public function addUser(Request $request){

            if(!isset($_SESSION['mentorId'])){
               return redirect()->intended('./mtr/login');
            }
            $data = array([
               'firstName'=>$request->firstName,
               'lastName'=>$request->lastName,
               'category'=>$request->category,
               'email'=>$request->email,
               'password'=>$request->password,
               'active'=>'1',
            ]);

            $db = DB::table('users');
            $validator = \Validator::make($data, $this->rules);

            if($validator->fails()){
               http_response_code(500);
               return redirect()->intended('./mtr/list');
            }

            $addJob = $db->insert($data);

            if($addJob){
               echo "New user added, redirecting...";
               sleep(4);
               return redirect()->intended('./mtr/newuser');
            }else{
               echo "Technical Error: Could not add user contact admin. Redirecting ....";
               sleep(4);
               return redirect()->intended('./mtr/list');
            }

      }

      public function addEmployer(Request $request){

         if(!isset($_SESSION['mentorId'])){
            return redirect()->intended('./mtr/login');
         }
            $data = array([
               'firstName'=>$request->firstName,
               'lastName'=>$request->lastName,
               'email'=>$request->email,
               'password'=>$request->password,
               'active'=>'1',
            ]);

            $db = DB::table('employers');
            $validator = \Validator::make($data, $this->rules);

            if($validator->fails()){
               http_response_code(500);
               return redirect()->intended('./mtr/list');
            }

            $addJob = $db->insert($data);

            if($addJob){
               echo "New employer added, redirecting...";
               sleep(4);
               return redirect()->intended('./mtr/newemployer');
            }else{
               echo "Technical Error: Could not add user contact admin. Redirecting ....";
               sleep(4);
               return redirect()->intended('./mtr/list');
            }

      }

      public function showDetails(Request $request){
         session_start();         
         if(!isset($_SESSION['mentorId'])){
            return redirect()->intended('./mtr/login');
         }
         $mentorId = $request->mentorId;

         $jobId =$request->jobId;
         //echo $jobId; --useless herr

         $jobs = DB::select('SELECT * FROM jobs WHERE jobId="'.$jobId.'"');
         return view('mentors.jobdetails',['jobs'=>$jobs]);
      }

      public function addJob(Request $request){
         session_start();
         if(!isset($_SESSION['mentorId'])){
            return redirect()->intended('./mtr/login');
         }

         $mentorId = $_SESSION['mentorId'];

         $data = array([
            'title'=>$request->title,
            'shortDesc'=>$request->shortDesc,
            'fullDesc'=>$request->fullDesc,
            'category'=>$request->category,
            'mentor'=>$request->mentor,
            'cost'=>$request->cost,
            'deadline'=>$request->deadline,
         ]);

         $validator = \Validator::make($data, $this->rules);

         if($validator->fails()){
            echo "Error: Wrong Data.Try again";
         }

         $addwork = DB::table('jobs')->insert($data);

         if($addwork){
            http_response_code(200);
            return redirect()->intended('./mtr/addjob');
         }else{
            echo "Technical Error: Contact Admin";
         }
      }
}
