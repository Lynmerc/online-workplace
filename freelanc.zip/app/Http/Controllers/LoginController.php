<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;

/**Do not modify this section or everything will crash -- Lynmercan*/

class LoginController extends Controller
{
	/*public function construct(){
		$this->middleware('guest')->except('logout');
		$this->middleware('guest:admin')->except('logout');
		$this->middleware('guest:users')->except('logout');
	}*/ //uncomment to use custom middleware:::be sure of what you're doing!!!! - Collins

    public function users(){
    	return view('auth.login',['url' => 'users']);
    }

    public function usersLogin(Request $request){
    	$this->validate($request, [
    		'email' => 'required|email',
    		'password' => 'required|min:8'
    	]);

    	if (Auth::guard('users')->attempt(['email'=>$request->email, 'password'=>$request->password], $request->get('remember'))){
    		return redirect()->intended('/users');
    	}

    	return back()->withInput($request->only('email','remember'));
    }

    public function admin(){
    	return view('auth.login', ['url'=>'admin']);
    }

    public function adminLogin(Request $request){
    	$this->validate($request, [
    		'email' => 'required|email',
    		'password' => 'required|min:8'
    	]);

    	if(Auth::guard('admin')->attempt(['email' => $request->email, 'password' => $request->password], $request->get('remember'))){

    		return redirect()->intended('/admin');
    	}

    	return back()->withInput($request->only('email','remember'));
    }

    public function employer(){
    	
    }
}
