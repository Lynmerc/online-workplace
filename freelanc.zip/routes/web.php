<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::post('/loger','LoginController@facade');
Route::post('/mloger','LoginController@mtrLogin');
Route::post('/eloger','LoginController@eprLogin');
Route::post('/apply','WorkController@showDetails');
Route::post('/apply2','WorkController@apply');
Route::post('/mtr/addjob','MentorController@addJob');
Route::post('/jobdetails','MentorController@showDetails');
Route::post('/respond','MentorController@respondToApplication');
Route::post('/mtr/add','LoginController@bgAdd');


Route::group(array('prefix'=>'usr'), function(){
        Route::get('/login',function(){return view('users.login_facade');});
        Route::get('/jobs', 'WorkController@fetchNewJobs');
        Route::get('/progress','WorkController@showWorkInProgress');
        Route::get('/applications','WorkController@showApplications');
        Route::get('/profile','LoginController@showProfile');

        
});

Route::group(array('prefix'=>'mtr'), function(){
        Route::get('/login',function(){return view('mentors.login_facade');});
        Route::get('/list', 'MentorController@mentorJobView');
        Route::get('/newjob',function(){return view('mentors.addjob');});
        Route::get('/progress','MentorController@showWorkInProgress');
        Route::get('/applications','MentorController@showApplications');
        Route::post('/loger','LoginController@mentorLogin');
        Route::get('/profile','LoginController@mentorProfile');
        Route::get('/adduser',function(){return view('mentors.adduser');});

});

Route::group(array('prefix'=>'epr'), function(){
        Route::get('/list','EprController@workList');
        Route::post('/new','EprController@newJob');
});
/*
Route::get('/home', function () {
    return view('welcome');
});

Route::group(array('prefix'=>'user'), function(){
	Route::get('/login', array('uses'=>'LoginController@login'))->name('user');
	Route::get('/find-work', array('uses'=>'WorkController@user_apply'))->name('user-apply');
	Route::get('/submit', array('uses'=>'WorkController@user_submit'))->name('user-submit');
	Route::get('/history', array('uses'=>'WorkController@user_history'))->name('user-history');
	Route::get('/profile', array('uses'=>'ProfilesController@user_profile'))->name('user-profile');
});


Route::group(array('prefix'=>'jobs'),
	function(){
		Route::group(['middleware'=>'adminOrUser'], function(){

		});
	}
);




Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
*

    Route::view('/', 'welcome');
    Auth::routes();

    Route::get('/login/admin', 'Auth\LoginController@showAdminLoginForm');
    Route::get('/login/writer', 'Auth\LoginController@showWriterLoginForm');
    Route::get('/register/admin', 'Auth\RegisterController@showAdminRegisterForm');
    Route::get('/register/writer', 'Auth\RegisterController@showWriterRegisterForm');

    Route::post('/login/admin', 'Auth\LoginController@adminLogin');
    Route::post('/login/writer', 'Auth\LoginController@writerLogin');
    Route::post('/register/admin', 'Auth\RegisterController@createAdmin');
    Route::post('/register/writer', 'Auth\RegisterController@createWriter');

    Route::view('/home', 'home')->middleware('auth');
    Route::view('/admin', 'admin');
    Route::view('/writer', 'writer'); */


