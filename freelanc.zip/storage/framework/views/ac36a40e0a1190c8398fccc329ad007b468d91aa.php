<!doctype html>
<html lang="en">
  <head>
  	<title>Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href=" <?php echo e(asset('css/style.css')); ?>">
  </head>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<div class="custom-menu">
					<button type="button" id="sidebarCollapse" class="btn btn-primary">
	          <i class="fa fa-bars"></i>
	          <span class="sr-only">Toggle Menu</span>
	        </button>
        </div>
				<div class="p-4">
		  		<h1><a href="index.html" class="logo">Freelanc <span>Freelancer Agency</span></a></h1>
	        <ul class="list-unstyled components mb-5">
	          <li class="active">
	            <a href="./jobs">Work List</a>
	          </li>
	          <li>
	              <a href="./profile">Profile</a>
	          </li>
	          <li>
	              <a href="./adduser">Add User</a>
	          </li>
	          <li>
	              <a href="./addjob">Add Job</a>
	          </li>
	          <li>
              <a href="./progress"></span>In Progress</a>
	          </li>
	          <li>
              <a href="./applications">Applications</a>
	          </li>
	          <li>
	              <a href="./submits">Submissions</a>
	          </li>
	        </ul>

	        <div class="mb-5">
						<h3 class="h6 mb-3">Subscribe for info</h3>
						<form action="#" class="subscribe-form">
	            <div class="form-group d-flex">
	            	<div class="icon"><span class="icon-paper-plane"></span></div>
	              <input type="text" class="form-control" placeholder="Enter Email Address">
	            </div>
	          </form>
					</div>

	        <div class="footer">
	        	<p>
						  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | <a href="https://lynmerc-enterprise.com" target="_blank" style="color: white;">Lynmercan</a>
						  </p>
	        </div>

	      </div>
    	</nav>
    	
        <!-- Page Content  -->
	      <div id="content" class="p-4 p-md-5 pt-5">
	      	<h2 class="mb-4">Open Jobs</h2> <hr />
	      	<div class="row">	      		
	      		<div class="col-md-1"></div>
	      		<div class="col-md-10">	      			
	      			<?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			        <div class="card mb-3" id="card" style="max-width: 640px;">
					  <div class="row no-gutters">
					    <div class="col-md-4">
					      <img src="./images/user.png" class="card-img" alt="...">
					    </div>
					    <div class="col-md-8">
					      <div class="card-body">
					        <h5 class="card-title" style="color: blue;"><?php echo e($job->title); ?></h5>
					        <p class="card-text"><?php echo e($job->shortDesc); ?></p>
					        <p class="small"><strong>Mentor:</strong> <?php echo e($job->mentor); ?>    <strong>Cost:</strong> Ksh. <?php echo e($job->cost); ?>     <strong>Deadline:</strong> <?php echo e($job->deadline); ?></p>
					      </div>
					      
					      <div class="card-footer">
					      	<form action="../jobdetails" method="POST">
					      		<input type="hidden" name="jobId" value="<?php echo e($job->jobId); ?>">
					      		<button class="btn btn-primary" type="./viewjob">View</button>
					      	</form>
					      	
					      </div>
					    </div>
					  </div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	      		</div>
	      		<div class="col-md-1"></div>
	      	</div>
	        
	      </div>

			
		</div>

    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
  </body>
</html><?php /**PATH C:\wamp\www\muli\resources\views/mentors/jobs.blade.php ENDPATH**/ ?>